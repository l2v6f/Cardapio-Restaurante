void editarBebida(){
	Restaurante x;
	FILE *fp;
	int cd;
		do{
		puts("Digite o Codigo do Prato Para Edicao");
		scanf("%i",&cd);
		if(cd<=0){
		printf("codigo invalido\n");	
		}
		}while(cd<=0);
			if((fp=fopen("bebida.bin", "r+b"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0 && x.tipo == 1) {
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo do Prato: Bebida\n");
					fseek(fp,sizeof(Restaurante)*-1,SEEK_CUR);
					puts("Alterar Dados\n");
					do{
						printf("Digite o Novo Preco\n");
						scanf("%f",&x.preco);
						if(x.preco<=0){
						printf("Preco Invalido\n");
						}
					}while(x.preco<=0);
					do{
						printf("Digite a Nova Descricao\n");
						fflush(stdin);
						gets(x.descricao);
						if(strcmp(x.descricao,"")==0){
							printf("A descricao nao pode ser vazia\n");
						}
					}while(strcmp(x.descricao,"")==0);
					fwrite(&x, sizeof(Restaurante), 1, fp);
					fseek(fp, sizeof(Restaurante)*0, SEEK_END);
					puts("Dado alterado com sucesso.");
				  }
			   }
			 fclose(fp);  
		   }
}

void editarComida(){
	Restaurante x;
	FILE *fp;
	int cd;
	
	do{
		puts("Digite o Codigo do Prato Para Edicao");
		scanf("%i",&cd);
		if(cd<=0){
		printf("codigo invalido\n");	
		}
	}while(cd<=0);
			if((fp=fopen("comida.bin", "r+b"))!=NULL){
					while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0) {
						printf("Codigo do Prato:%i\n",x.codigo);
						printf("Nome Do Prato: %s\n", x.nome);
						printf("Preco Do Prato: %.2f\n",x.preco);
						printf("Descricao do prato:%s\n",x.descricao);
						printf("Tipo do Prato: Comida\n");
						fseek(fp,sizeof(Restaurante)*-1,SEEK_CUR);
						puts("Alterar Dados\n");
					do{
						printf("Digite o Novo Preco\n");
						scanf("%f",&x.preco);
						if(x.preco<=0){
						printf("Preco Invalido\n");
						}
					}while(x.preco<=0);
					do{
						printf("Digite a Nova Descricao\n");
						fflush(stdin);
						gets(x.descricao);
						if(strcmp(x.descricao,"")==0){
						printf("A descricao nao pode ser vazia\n");
						}
					}while(strcmp(x.descricao,"")==0);
						fwrite(&x, sizeof(Restaurante), 1, fp);
						fseek(fp, sizeof(Restaurante)*0, SEEK_END);
						puts("Dado alterado com sucesso.");
			       }
				 
			   }
			   fclose(fp);
		}
}

void editarVinho(){
	Restaurante x;
	FILE *fp;
	int cd;
	
	do{
		puts("Digite o Codigo do Prato Para Edicao");
		scanf("%i",&cd);
		if(cd<=0){
		printf("codigo invalido\n");	
		}
	}while(cd<=0);
				if((fp=fopen("vinho.bin", "r+b"))!=NULL){
					while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0) {
						printf("Codigo do Prato:%i\n",x.codigo);
						printf("Nome Do Prato: %s\n", x.nome);
						printf("Preco Do Prato: %.2f\n",x.preco);
						printf("Descricao do prato:%s\n",x.descricao);
						printf("Tipo do Prato: Vinho\n");
						fseek(fp,sizeof(Restaurante)*-1,SEEK_CUR);
						puts("Alterar Dados\n");
					do{
						printf("Digite o Novo Preco\n");
						scanf("%f",&x.preco);
						if(x.preco<=0){
						printf("Preco Invalido\n");
						}
					}while(x.preco<=0);
					do{
						printf("Digite a Nova Descricao\n");
						fflush(stdin);
						gets(x.descricao);
						if(strcmp(x.descricao,"")==0){
						printf("A descricao nao pode ser vazia\n");
						}
					}while(strcmp(x.descricao,"")==0);
						fwrite(&x, sizeof(Restaurante), 1, fp);
						fseek(fp, sizeof(Restaurante)*0, SEEK_END);
						puts("Dado alterado com sucesso.");
			    }
			}
		fclose(fp);
   	}
}
