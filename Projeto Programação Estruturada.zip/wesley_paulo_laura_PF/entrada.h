void leValidaNome(char nome[]);
float leValidaPreco();
int leValidaCodigo();
void leValidaDescricao(char descricao[]);
int leValidaTipo();

Restaurante cadastrar() {
	Restaurante x;
	leValidaNome(x.nome);
	x.preco = leValidaPreco();
	x.codigo = leValidaCodigo();
	leValidaDescricao(x.descricao);
	x.tipo = leValidaTipo();
	x.removido = 0;
	return x;
}
void armazenar(Restaurante x){
	FILE *fp,*bebida,*comida,*vinho;
	if((fp=fopen("restaurante.bin", "ab"))!= NULL){
		fwrite(&x,sizeof(Restaurante),1,fp);
		fclose(fp);
	}else{
		puts("Arquivo nao encontrado");
	}
	bebida = fopen("bebida.bin", "wb");
	if((fp=fopen("restaurante.bin", "rb"))!= NULL){
		while(fread(&x,sizeof(Restaurante),1,fp)==1){
			if(x.tipo==1 && x.removido==0){
				fwrite(&x,sizeof(Restaurante), 1, bebida);
			}
		}
		fclose(fp);
		fclose(bebida);	
	}
	comida = fopen("comida.bin", "wb");
	if((fp=fopen("restaurante.bin", "rb"))!= NULL){
		while(fread(&x,sizeof(Restaurante),1,fp)==1){
			if(x.tipo==2 && x.removido==0){
				fwrite(&x,sizeof(Restaurante), 1, comida);
			}
		}
		fclose(fp);
		fclose(comida);	
	}
	vinho = fopen("vinho.bin", "wb");
	if((fp=fopen("restaurante.bin", "rb"))!= NULL){
		while(fread(&x,sizeof(Restaurante),1,fp)==1){
			if(x.tipo==3 && x.removido==0){
				fwrite(&x,sizeof(Restaurante), 1, vinho);
			}
		}
		fclose(fp);
		fclose(vinho);	
	}
}

void leValidaNome(char nome[]) {
	do {
		printf("Digite o Nome do Prato a Ser Cadastrado\n");
		fflush(stdin);
		gets(nome);
		if(strcmp(nome,"")==0) {
			printf("Nome invalido\n");
		}
	} while(strcmp(nome,"")==0);
}
int leValidaCodigo() {
	int cod, flag=0;
	FILE *fp;
	Restaurante x;
	do {
		flag=0;
		printf("Digite o do numero do Codigo do Prato a Ser Cadastrado\n");
		scanf("%i",&cod);
		if(cod<0) {
			printf("O numero do codigo invalido");
			flag=1;
		}else if((fp=fopen("restaurante.bin", "rb"))!=NULL){
			while(fread(&x,sizeof(Restaurante),1,fp)==1){
				if(cod==x.codigo) {
					printf("O n�mero do codigo deve ser diferente.\n");
					flag=1;
					break;
				}
			}
		fclose(fp);
	}
	} while(flag==1);
	return cod;
}
float leValidaPreco() {
	float preco;
	do {
		printf("Digite o Preco do Prato a Ser Cadastrado\n");
		scanf("%f",&preco);
		if(preco<0) {
			printf("preco digitado e invalido\n");
		}
	} while(preco<0);
	return preco;
}
void leValidaLogin(char login[]) {
	do {
		printf("Digite o Login de Acesso\n");
		fflush(stdin);
		gets(login);
		if(strcmp(login,"")==0) {
			printf("Login Invalido\n");
		}
	} while(strcmp(login,"")==0);
}
void leValidaSenha(char senha[]) {
	do {
		printf("Digite a Senha de Acesso\n");
		gets(senha);
		if(strcmp(senha,"")==0) {
			printf("Senha Invalido\n");
		}
	} while(strcmp(senha,"")==0);
}
void leValidaDescricao(char descricao[]) {
	do {
		printf("Digite a Descricao do Prato a Ser Cadastrado\n");
		fflush(stdin);
		gets(descricao);
		if(strcmp(descricao,"")==0) {
			printf("Descricao invalida\n");
		}
	} while(strcmp(descricao,"")==0);
}
int leValidaTipo() {
	int tipo;
	do {
		puts("Selecione o Tipo");
		puts("1-Bebida");
		puts("2-Comida");
		puts("3-Vinho");
		scanf("%i",&tipo);
		if(tipo<=0 || tipo>3) {
			printf("\nOpcao Invalida\n");
		}
	} while(tipo<=0 || tipo>3);
	return tipo;
}

