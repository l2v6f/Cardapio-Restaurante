struct restaurante{
	char nome[30];
	int codigo;
	float preco;
	char descricao[30];
	int tipo;
	int removido;
};
typedef struct restaurante Restaurante;


