void excluirBebida(){
	FILE *fp,*ex;
	int cod;
	Restaurante x,y;

	if((fp=fopen("bebida.bin", "r+b"))!=NULL){
		puts("Digite o Codigo a ser Removido:\n");
		scanf("%i", &cod);
		while(fread(&x, sizeof(Restaurante), 1, fp)==1){
			if(cod ==  x.codigo && x.removido == 0){
				fseek(fp, sizeof(Restaurante)*-1, SEEK_CUR);
				x.removido=1;
				fwrite(&x, sizeof(Restaurante), 1, fp);
				fseek(fp, sizeof(Restaurante)*0, SEEK_END);
				puts("Dado removido com sucesso.");
			}
		}
		fclose(fp);	
	}
		if((ex=fopen("restaurante.bin", "r+b"))!=NULL){
		while(fread(&y, sizeof(Restaurante), 1, ex)==1){
			if(cod ==  y.codigo && y.removido==0){
				fseek(ex, sizeof(Restaurante)*-1, SEEK_CUR);
				y.removido=1;
				fwrite(&y, sizeof(Restaurante), 1, ex);
				fseek(ex, sizeof(Restaurante)*0, SEEK_END);
			}
		}
		fclose(ex);	
	}
}

void excluirComida(){
	FILE *fp,*ex;
	int cod;
	Restaurante x,y;

	if((fp=fopen("comida.bin", "r+b"))!=NULL){
		puts("Digite o Codigo a ser Removido:\n");
		scanf("%i", &cod);
		while(fread(&x, sizeof(Restaurante), 1, fp)==1){
			if(cod ==  x.codigo && x.removido == 0){
				fseek(fp, sizeof(Restaurante)*-1, SEEK_CUR);
				x.removido=1;
				fwrite(&x, sizeof(Restaurante), 1, fp);
				fseek(fp, sizeof(Restaurante)*0, SEEK_END);
				puts("Dado removido com sucesso.");
			}
		}
		fclose(fp);	
	}
		if((ex=fopen("restaurante.bin", "r+b"))!=NULL){
		while(fread(&y, sizeof(Restaurante), 1, ex)==1){
			if(cod ==  y.codigo && y.removido==0){
				fseek(ex, sizeof(Restaurante)*-1, SEEK_CUR);
				y.removido=1;
				fwrite(&y, sizeof(Restaurante), 1, ex);
				fseek(ex, sizeof(Restaurante)*0, SEEK_END);
			}
		}
		fclose(ex);	
	}
	
}


void excluirVinho(){
	FILE *fp,*ex;
	int cod;
	Restaurante x,y;

	if((fp=fopen("vinho.bin", "r+b"))!=NULL){
		puts("Digite o Codigo a ser Removido:\n");
		scanf("%i", &cod);
		while(fread(&x, sizeof(Restaurante), 1, fp)==1){
			if(cod ==  x.codigo && x.removido == 0){
				fseek(fp, sizeof(Restaurante)*-1, SEEK_CUR);
				x.removido=1;
				fwrite(&x, sizeof(Restaurante), 1, fp);
				fseek(fp, sizeof(Restaurante)*0, SEEK_END);
				puts("Dado removido com sucesso.");
			}
		}
		fclose(fp);	
	}
		if((ex=fopen("restaurante.bin", "r+b"))!=NULL){
		while(fread(&y, sizeof(Restaurante), 1, ex)==1){
			if(cod ==  y.codigo && y.removido==0){
				fseek(ex, sizeof(Restaurante)*-1, SEEK_CUR);
				y.removido=1;
				fwrite(&y, sizeof(Restaurante), 1, ex);
				fseek(ex, sizeof(Restaurante)*0, SEEK_END);
			}
		}
		fclose(ex);	
	}
	
}

