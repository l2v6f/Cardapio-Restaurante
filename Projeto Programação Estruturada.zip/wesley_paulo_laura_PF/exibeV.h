void exibeV(){
	
	FILE *fp;
			
	Restaurante vetor [500];
		
 	int i, aux, contador,TAM;
		
	if ((fp = fopen ("vinho.bin", "rb")) != NULL) {
		while (fread (&vetor[i], sizeof (Restaurante), 1, fp) == 1) {
			i++;
		}	
	}
	TAM = i;
 for (contador = 1; contador < TAM; contador++) {
   for (i = 0; i < TAM - 1; i++) {
     if (vetor[i].codigo > vetor[i + 1].codigo) {
       aux = vetor[i].codigo;
       vetor[i].codigo = vetor[i + 1].codigo;
       vetor[i + 1].codigo = aux;
     }
   }
 }
	for (i = 0; i < TAM; i++) {
		if (vetor[i].removido == 0) {
			system("color 04");
			printf ("Codigo:    %i\n", vetor[i].codigo);
			printf ("Produto:   %s\n", vetor[i].nome);
			printf ("Descricao: %s\n", vetor[i].descricao);
			printf ("Preco:     R$ %.2f\n", vetor[i].preco);	
			printf ("Tipo:      Vinho\n\n");
		}
	}
	fclose(fp);
}
