//Nome: Paulo Cesar Alves dos Reis. Matr�cula: uc20100466  
//Nome:	Laura Vieira Fernandes.		Matricula: uc20103268
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "estrutura.h"
#include "entrada.h"
#include "pesquisa.h"
#include "exibicao.h"
#include "exibeC.h"
#include "exibeV.h"
#include "editar.h"
#include "excluir.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char *argv[]) {
	char login[25];
	char senha[25];
	int op,op2,op3,op4,op5,op6,op7,flag,cont,contT;
	Restaurante x;
do{
	system("cls");
	system("color 07");
	puts("Menu de Opcoes");
	puts("1-Cliente");
	puts("2-Administrativo");
	puts("3-Sair");
	scanf("%i", &op);
	if(op!=1 && op!=2 && op!=3) {
		printf("Opcao Invalida\n");
	}
	if(op==1){
	do{
		system("cls");
		system("color 07");
		puts("Menu De Opcoes Do Cardapio");
		puts("1-Bebidas");
		puts("2-Comidas");
		puts("3-Vinhos");
		puts("4-Retornar Ao Menu Principal");
		scanf("%i",&op2);
		if(op2!=1 && op2!=2 && op2!=3 && op2!=4) {
			printf("Opcao Invalida\n");
		}
		switch(op2){
		case 1:
			system("cls");
			exibir();
			system("pause");
			break;
		case 2:
			system("cls");
			exibeC();
			system("pause");
			break;
		case 3:
			system("cls");
			exibeV();
			system("pause");
			break;
		case 4:
			system("cls");
			system("pause");
			break;
		default:
			puts("Opcao Invalida");
			break;
		}
	}while(op2!=4);
	}else if(op==2){
		do {
			flag=0;
			system("cls");
			leValidaLogin(login);
			leValidaSenha(senha);
			if(strcmp(login,"paulo")!=0 || strcmp(senha,"admin")!=0) {
				printf("Credenciais Invalidas\n");
				flag=1;
				cont++;	
			}
			system("pause");
		} while(flag==1 && cont<3);
		if(cont<3){
	do{
			system("cls");
			system("color 07");
			puts("Seja Bem Vindo!");
			puts("Menu de Opcoes");
			puts("1-Cadastrar");
			puts("2-Editar");
			puts("3-Excluir");
			puts("4-Pesquisar");
			puts("5-Exibicao Do Cardapio");
			puts("6-Retornar Ao Menu Principal");
			scanf("%i",&op3);
			if(op3!=1 && op3!=2 && op3!=3 && op3!=4 && op3!=5 && op3!=6) {
				printf("Opcao Invalida\n");
			}
		switch(op3) {
		case 1:
				system("cls");
				armazenar(cadastrar());
				system("pause");
				break;
		case 2:
			do{
				system("cls");
				system("color 07");
				puts("Selecione o Prato Para Realizar a Edicao");
				puts("1-Bebidas");
				puts("2-Comidas");
				puts("3-Vinhos");
				puts("4-Retornar Ao Menu Anterior");
				scanf("%i",&op6);
				if(op6!=1 && op6!=2 && op6!=3 && op6!=4) {
					printf("Opcao Invalida\n");
				}
		 	switch(op6){
			case 1:
				system("cls");
				editarBebida();
				system("pause");
				break;
			case 2:
				system("cls");
				editarComida();
				system("pause");
				break;
			case 3:
				system("cls");
				editarVinho();
				system("pause");
				break;
			case 4:
				system("cls");
				system("pause");
				break;
			default:
				puts("Opcao Invalida");
				break;
		   }
		}while(op6!=4);
		break;
		case 3:
				do{
				system("cls");
				system("color 07");
				puts("Selecione o Prato Para Realizar a Exclusao");
				puts("1-Bebidas");
				puts("2-Comidas");
				puts("3-Vinhos");
				puts("4-Retornar Ao Menu Anterior");
				scanf("%i",&op7);
				if(op7!=1 && op7!=2 && op7!=3 && op7!=4) {
					printf("Opcao Invalida\n");
				}
		 	switch(op7){
			case 1:
				system("cls");
				excluirBebida();
				system("pause");
				break;
			case 2:
				system("cls");
				excluirComida();
				system("pause");
				break;
			case 3:
				system("cls");
				excluirVinho();
				system("pause");
				break;
			case 4:
				system("cls");
				system("pause");
				break;
			default:
				puts("Opcao Invalida");
				break;
		   }
		}while(op7!=4);
		break;
		case 4:
		do{
				system("cls");
				system("color 07");
				puts("Selecione o Prato Para Realizar a Pesquisa");
				puts("1-Bebidas");
				puts("2-Comidas");
				puts("3-Vinhos");
				puts("4-Retornar Ao Menu Anterior");
				scanf("%i",&op5);
				if(op5!=1 && op5!=2 && op5!=3 && op5!=4) {
					printf("Opcao Invalida\n");
				}
		 	switch(op5){
			case 1:
				system("cls");
				pesquisaBebida();
				system("pause");
				break;
			case 2:
				system("cls");
				pesquisaComida();
				system("pause");
				break;
			case 3:
				system("cls");
				pesquisaVinho();
				system("pause");
				break;
			case 4:
				system("cls");
				system("pause");
				break;
			default:
				puts("Opcao Invalida");
				break;
		   }
		}while(op5!=4);
		break;
		case 5:
		do{
				system("cls");
				system("color 07");
				puts("Menu De Opcoes Do Cardapio");
				puts("1-Bebidas");
				puts("2-Comidas");
				puts("3-Vinhos");
				puts("4-Retornar Ao Menu Anterior");
				scanf("%i",&op4);
				if(op4!=1 && op4!=2 && op4!=3 && op4!=4) {
					printf("Opcao Invalida\n");
				}
		 	switch(op4){
			case 1:
				system("cls");
				exibir();
				system("pause");
				break;
			case 2:
				system("cls");
				exibeC();
				system("pause");
				break;
			case 3:
				system("cls");
				exibeV();
				system("pause");
				break;
			case 4:
				system("cls");
				break;
			default:
				puts("Opcao Invalida");
				break;
		   }
		}while(op4!=4);
		case 6:
		   	system("cls");
		   	system("pause");
		   	break;
      	}
	}while(op3!=6);
	}else{
		puts("Limite De Tentativas Execedido!");
	}
	}else if(op==3){
	exit(1);
	}
}while(op!=3);
	return 0;
}
