void pesquisaBebida() {
	char nm[35];
	int cd,tp;
	Restaurante x;
	FILE *fp;
	do {
		puts("Menu De Opcoes");
		puts("1-Pesquisa Por Nome do Prato\n");
		puts("2-Pesquisa Por Codigo do Prato\n");
		scanf("%i",&tp);
		if(tp<=0 || tp>2) {
			printf("Opcao invalida\n");
		}
	} while(tp<=0 || tp>2);
	if(tp==1) {
		system("cls");
	do {
		printf("Digite o Nome do Prato Para Pesquisa \n");
		fflush(stdin);
		gets(nm);
		if(strcmp(nm,"")==0) {
			printf("Nome invalido\n");
		}
	} while(strcmp(nm,"")==0);
			if((fp=fopen("bebida.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(strcmp(x.nome,nm)==0 && x.removido==0) {
					system("color 06");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Bebida\n");
					}
				}
				fclose(fp);
			}
	} else {
		system("cls");
		do{
			puts("Digite o Codigo do Prato Para Pesquisa\n");
			scanf("%i",&cd);
			if(cd<=0){
				printf("codigo invalido\n");	
			}
		}while(cd<=0);
			if((fp=fopen("bebida.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0) {
					system("color 06");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Bebida\n");
					}
				}
				fclose(fp);
		  }
     }
 }
 void pesquisaComida() {
	char nm[35];
	int cd,tp;
	Restaurante x;
	FILE *fp;
	do {
		puts("Menu De Opcoes");
		puts("1-Pesquisa Por Nome do Prato\n");
		puts("2-Pesquisa Por Codigo do Prato\n");
		scanf("%i",&tp);
		if(tp<=0 || tp>2) {
			printf("Opcao invalida\n");
		}
	} while(tp<=0 || tp>2);
	if(tp==1) {
		system("cls");
	do {
		printf("Digite o Nome do Prato Para Pesquisa \n");
		fflush(stdin);
		gets(nm);
		if(strcmp(nm,"")==0) {
			printf("Nome invalido\n");
		}
	} while(strcmp(nm,"")==0);
			if((fp=fopen("comida.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(strcmp(x.nome,nm)==0 && x.removido==0) {
					system("color 0A");
					system("cls");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Comida\n");
					}
				}
				fclose(fp);
			}
	} else {
		system("cls");
		do{
		puts("Digite o Codigo do Prato Para Pesquisa\n");
		scanf("%i",&cd);
		if(cd<=0){
		printf("codigo invalido\n");	
		}
		}while(cd<=0);
		if((fp=fopen("comida.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0) {
					system("color 0A");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Comida\n");
					}
				}
				fclose(fp);
			}
     }
 }
 
void pesquisaVinho() {
	char nm[35];
	int cd,tp;
	Restaurante x;
	FILE *fp;
	do {
		puts("Menu De Opcoes");
		puts("1-Pesquisa Por Nome do Prato\n");
		puts("2-Pesquisa Por Codigo do Prato\n");
		scanf("%i",&tp);
		if(tp<=0 || tp>2) {
			printf("Opcao invalida\n");
		}
	} while(tp<=0 || tp>2);
	if(tp==1) {
	do {
		printf("Digite o Nome do Prato Para Pesquisa \n");
		fflush(stdin);
		gets(nm);
		if(strcmp(nm,"")==0) {
			printf("Nome invalido\n");
		}
	} while(strcmp(nm,"")==0);
			if((fp=fopen("vinho.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(strcmp(x.nome,nm)==0 && x.removido==0) {
					system("color 04");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Vinho\n");
					}
				}
				fclose(fp);
			}
	} else {
		system("cls");
		do{
		puts("Digite o Codigo do Prato Para Pesquisa\n");
		scanf("%i",&cd);
		if(cd<=0){
		printf("codigo invalido\n");	
		}
		}while(cd<=0);
		if((fp=fopen("vinho.bin", "rb"))!=NULL){
				while(fread(&x,sizeof(Restaurante),1,fp)==1){
					if(cd==x.codigo && x.removido==0) {
					system("color 04");
					printf("Codigo do Prato:%i\n",x.codigo);
					printf("Nome Do Prato: %s\n", x.nome);
					printf("Preco Do Prato: %.2f\n",x.preco);
					printf("Descricao do prato:%s\n",x.descricao);
					printf("Tipo Do Prato: Vinho\n");
					}
				}
			fclose(fp);
		}
     }
 }

